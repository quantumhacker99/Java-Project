package imt2018028;
import java.util.ArrayList;
import animation.*;

public class deriveScene extends Scene{
	
	public deriveScene(){
		super();
	}

	public void checkScene(){
		int i, j;
		for(i=0; i<this.getActors().size(); i++){ 				//Checking throughtout all the actors to check for collisions
			for(j=0;j<this.getActors().size();j++){
				if(this.getActors().get(i)!= this.getActors().get(j)){
					if(this.getActors().get(i).getBBox().intersects(getActors().get(j).getBBox())){
						this.getActors().remove(this.getActors().get(j));
						this.getActors().remove(this.getActors().get(i));
				}
			}
		}
			}
		for(i=0; i<this.getObstacles().size(); i++){				//Checking if actor collides with obstacles
			for(j=0;j<this.getActors().size();j++){
				if(this.getObstacles().get(i)!= this.getActors().get(j)){
					if(this.getObstacles().get(i).getBBox().intersects(this.getActors().get(j).getBBox())){
						this.getActors().remove(this.getActors().get(j));
						this.getObstacles().remove(this.getObstacles().get(i));
				}
			}
		}
			}

	
	}

	}
