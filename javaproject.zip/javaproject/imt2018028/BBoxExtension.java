package imt2018028;
import animation.*;
import java.util.Scanner;

public class BBoxExtension implements BBox{
	private Point p1,p2;
	public BBoxExtension(int x_min, int y_min,int x_max,int y_max){
		p1 = new Point(x_min,y_min); 			//Constructing the object by intializing the min point and max point, which are sufficient to describe the entire BBox
		p2 = new Point(x_max,y_max);
	}
	
	public Point getMinPt(){
		return p1;
	}
	
	public Point getMaxPt(){
		return p2;
	}

	public int getWidth(){
		return (p2.getX() - p1.getX());
	}

	public int getHeight(){
		return (p2.getY() - p1.getY());
	}

	public boolean intersects(BBox b){					//If the x coordinate of max point of one is less than x coordinate of min point of another, there can be no collision. We 										apply this principle multiple times
		if( p2.getX() < b.getMinPt().getX())
			return false;
		if( p2.getY() < b.getMinPt().getY())
			return false;
		if( b.getMaxPt().getX() < p1.getX())
			return false;
		if( b.getMaxPt().getY() < p1.getY())
			return false;
		return true;
	}

	@Override
	public String toString(){
		return "(:"+this.getMinPt().getX()+","+this.getMinPt().getY()+"), ("+this.getMaxPt().getX()+","+this.getMaxPt().getY();
	}
}



