package imt2018028;

import java.util.ArrayList;
import java.util.Random;

import animation.*;
public class DemoSceneObject extends SceneObject {
	private String name;
	private Point pos;
	private Point dest_pos;
	private ArrayList<Point> outline;
	private static int i=0;
	private BBoxExtension b2;
	public boolean iscolliding;
	public int counter;
	Random random = new Random();

	public DemoSceneObject(){
		super();					//Initializing using constructor of superclass				
		this.name = "a";
		pos = new Point(0,0);
		dest_pos = new Point(0,0);
		this.outline = new ArrayList<Point>();
		i++;						//Constructing the attributes required
	}

	@Override
	public String getObjName() {
		return name + i; 				//Returning name of object
	}

	@Override
	public Point getPosition() {
		return pos;					//Returning position of object
	}

	@Override
	public void setPosition(int x, int y) {
		pos = new Point(x,y);
		this.outline.clear();
		this.outline.add(pos);
		Point newPt = new Point(x + 10, y+10);
		this.outline.add(newPt);			//We are using this only for initialization of the object
	}

	private void movePosition(int dX, int dY) {
		int x_store, y_store;
		for( Point p : this.outline){			//A new method used to move the object
			x_store = p.getX();
			y_store = p.getY();
			System.out.println("dX is " + dX);
			p.setPos(x_store + dX, y_store + dY);
		}
	}


	public void setDestPosition(int x, int y) {
		dest_pos.setPos(x,y);				//To set the position of the destination
	}

	@Override
	public BBoxExtension getBBox() {
		int x_max,x_min,y_max,y_min;
		x_max = x_min = this.outline.get(0).getX();
		y_max = y_min = this.outline.get(0).getY();
		for(Point p:this.outline){
			if( p.getX() > x_max)
				x_max = p.getX();
			if( p.getX() < x_min)
				x_min = p.getX();
			if( p.getY() > y_max)
				y_max = p.getY();
			if( p.getY() < y_min)
			       y_min = p.getY();
		}
		return new BBoxExtension(x_min,y_min,x_max,y_max);		//Constructing BBox of the object
	}

	private BBoxExtension create_new_BBox(int x, int y, int w, int h, int dx, int dy){
		return new BBoxExtension( x+dx,y+dy, x+w+dx, y+h+dy);			//Creating a new BBox at desired location
	}


	@Override
	public ArrayList<Point> getOutline() {
		return this.outline;						//To get the outline
	} 

	private boolean checkColl(int dX, int dY){
		BBoxExtension b = create_new_BBox(pos.getX(),pos.getY(),this.getBBox().getWidth(), this.getBBox().getHeight(), dX,dY);

		for(SceneObject elem: Scene.getScene().getActors()){			//We create a BBox at the point we wish to move our object to and check intersection between that BBox and the actor
			if( this != elem){
				if( b.intersects(elem.getBBox())){
					iscolliding = true;
					return true;
				}
			}
		}
		for(SceneObject elem2 : Scene.getScene().getObstacles()){		//Same as above, except for obstacles
			if( this != elem2){
				if( b.intersects(elem2.getBBox())){
					iscolliding = true;
					return true;
				}
			}
		}
		return false;
		
	}

	public void updatePos(int deltaT){
		iscolliding = false;
		if( Math.abs(pos.getX() - dest_pos.getX()) <= 10 && Math.abs(pos.getY() - dest_pos.getY()) <= 10)	//If the actors come within 10 units of destination it should not update further
			return;
		int dX,dY, x_init, y_init,x_count,y_count, width,height,count=0;
		int dX2 = (dest_pos.getX() - pos.getX()), dY2 = dest_pos.getY() - pos.getY();

		
		if( dX2 > 10 || dX2 < -10){		//If distance between destination and object is >10 we set the movement of the object to only 10 units, else we let it cover the entire distance
			if( dX2 > 0)
				dX = 10;
			else
				dX = -10;
		}
		else{
			dX = dX2;
		}

		if( dY2 > 10 || dY2 < -10){		
			if( dY2 > 0)
				dY = 10;
			else
				dY = -10;
		}
		else{
			dY = dY2;
		}

		boolean inter, check = true;	
		
		while (check){				//Keep iterating till a suitable position to move to is found
		inter = checkColl(dX,dY);		//First try to move in direction of destination
		if(inter){				//If there is collision there then we try moving left, right, up or down.
				count = random.nextInt(4);			//Randomly choose which direction to move in 
				if( count == 0){
					if(pos.getX() != 0){
						if( pos.getX() > 10){
							inter = checkColl(-10,0);
						}
						else{
							inter = checkColl(-pos.getX(),0);

						}
					}
					if(!(inter)){
						if( pos.getX() > 10)
							movePosition(-10,0);
						else
							movePosition(-pos.getX(),0);
						check = false;
					}
					else{
						count = random.nextInt(4);
					}

				}

				if( count == 1){

					inter = checkColl(10,0);
					
					if(!(inter)){
						movePosition(10,0);
						check = false;
					}
					else
						count = random.nextInt(4);
				}
				
				if( count == 2){
					inter = checkColl(0,10);
					if(!(inter)){
						movePosition(0,10);
						check = false;
					}
					else
						count = random.nextInt(4);
				}

				if( count == 3){
					if(pos.getY()!= 0){
					if( pos.getY() > 10){
						inter = checkColl(0,-10);

					}
					else{
						inter = checkColl(0,-pos.getY());
					}
						}
					if(!(inter)){
						if( pos.getY() > 10){
							movePosition(0,-10);
						}
						else {
							movePosition(0,-pos.getY());
							}
						}
						check = false;
					}
					else{
						count = random.nextInt(4);
					}
			}
			else{
				movePosition(dX,dY);
				check = false;
			}
		

	}
}
}
